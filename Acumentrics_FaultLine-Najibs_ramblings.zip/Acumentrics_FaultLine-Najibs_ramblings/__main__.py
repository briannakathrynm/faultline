import argparse
import os
import random
import sys

import numpy as np
import pandas as pd

import Training
import config

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'


if __name__ == "__main__":
    np.random.seed(42)
    random.seed(42)
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description='Train model on PLAID dataset')
    parser.add_argument('--source', '-s', dest='data_source', required=True, type=int,
                        help='Data source of the input data')
    parser.add_argument('--epochs', action='store', dest='epochs', required=True, type=int,
                        help='Set the number of training epochs')
    parser.add_argument('--batch', action='store', dest='batch_size', default=1, type=int,
                        help='Set the batch size for the training (Default: 1)')
    parser.add_argument('--export', action='store_true', dest='export',
                        help='Set flag to export the model (Default: False')
    parser.add_argument('--input', '-i', action='store', dest='input', default="default",
                        help='Define input directory name in Training Data')
    parser.add_argument('--infer', action='store', dest='inference', default=None,
                        help='Define inference directory name in Training Data')
    parser.add_argument('--load', action='store', dest='model_path', default='',
                        help='Set the starting point of the model via a model file path')
    parser.add_argument('--partitions', action='store', nargs=3, dest='partition_sizes', default=[0.5, 0.4, 0.1],
                        type=float,
                        help='Set the size of the training, validation, and test partitions (Default: 0.5, 0.4, 0.1')
    parser.add_argument('--output', '-o', action='store', dest='output', default="default",
                        help='Define output directory name in Training Results')
    parser.add_argument('-v', '--verbose', action='store_true', dest='isVerbose',
                        help='Print additional information to the standard output')
    parser.add_argument('--visualize', action='store_true', dest='isVisualized',
                        help='Produce visualization of the model structure')
    parser.add_argument('--window', action='store', dest='window_length', default=0.1, type=float,
                        help='Set the length of the data window in seconds (Default: 0.1)')
    parser.add_argument('--down_sampling_rate', '-dsr', action='store', dest='down_sampling_rate', default=1, type=int,
                        help='Set the down sampling rate of the input (Default: 1)')
    args = parser.parse_args()

    input_path = os.path.join(config.TRAINING_DATA_PATH, args.input)
    output_path = os.path.join(config.TRAINING_RESULTS_PATH, args.output)

    # Read meta CSV data
    meta = pd.read_csv(os.path.join(input_path, "meta.csv")).to_numpy()

    # Determine the number of columns in the power binary
    # noinspection DuplicatedCode
    num_of_features: int = 0
    window_size: float = 0.
    if args.data_source == config.DataSource.PLAID:
        num_of_features = config.PLAIDPowerData.NUM_OF_COLS
        window_size = float(np.floor(args.window_length * config.INPUT_FREQ))
    elif args.data_source == config.DataSource.PEL:
        num_of_features = config.PELData.NUM_OF_COLS
        window_size = float(args.window_length)
    elif args.data_source == config.DataSource.ADE7880:
        num_of_features = config.ADE7880Data.NUM_OF_COLS
        window_size = float(args.window_length)
    else:
        print("Invalid data source type (See config for full list of sources")
        sys.exit(1)

    # Read data from binary file
    data = np.memmap(
        filename=os.path.join(input_path, "total_power.memmap"),
        dtype=np.float64,
        mode="r",
        shape=(meta[meta.shape[0] - 1][config.Meta.END_ROW] + 1, num_of_features)
    )

    # Create an instance of the training object
    training = Training.Training(
        num_of_features=num_of_features,
        data=data,
        epochs=args.epochs,
        input_path=input_path,
        # meta=meta,
        output_path=output_path,
        batch_size=args.batch_size,
        part_sizes=args.partition_sizes,
        visualize=args.isVisualized,
        verbose=args.isVerbose,
        window_size=window_size,
        down_sampling_rate=args.down_sampling_rate
    )

    # If the user gave an input model, load the model. If not, build one
    training.build()
    training.train()
    training.evaluate()
    if args.inference:
        inference_path = os.path.join(config.TRAINING_DATA_PATH, args.inference)
        # training.inference(inference_path)
    training.save()
    if args.export:
        training.export()
