from enum import IntEnum

PLAID_PATH = "./Plaid/"
TRAINING_DATA_PATH = "./TrainingData/"
RAW_DATA_PATH = "./RawData/"
TRAINING_RESULTS_PATH = "./TrainingResults/"
INFERENCE_RESULTS_PATH = "./InferenceResults"
SAMPLING_FREQ = 30_000
INPUT_FREQ = 60

ADE7880_DATA_FREQ = 2_000

PARTITION_SIZES = {"train": 0.6, "valid": 0.2, "test": 0.2}
OFFSET = 10_000
CLASS_LENGTH = 3_600_000
TRAIN_LENGTH = PARTITION_SIZES["train"] * CLASS_LENGTH
VALID_LENGTH = PARTITION_SIZES["valid"] * CLASS_LENGTH
TEST_LENGTH = PARTITION_SIZES["test"] * CLASS_LENGTH

TRAIN_INDICES = {
    0: (CLASS_LENGTH + OFFSET, CLASS_LENGTH + OFFSET + TRAIN_LENGTH),
    1: (OFFSET, OFFSET + TRAIN_LENGTH),
    2: (2 * CLASS_LENGTH + OFFSET, 2 * CLASS_LENGTH + OFFSET + TRAIN_LENGTH),
}

VALID_INDICES = {
    0: (TRAIN_INDICES[0][1], TRAIN_INDICES[0][1] + VALID_LENGTH),
    1: (TRAIN_INDICES[1][1], TRAIN_INDICES[1][1] + VALID_LENGTH),
    2: (TRAIN_INDICES[2][1], TRAIN_INDICES[2][1] + VALID_LENGTH)
}

TEST_INDICES = {
    0: (VALID_INDICES[0][1], VALID_INDICES[0][1] + TEST_LENGTH - OFFSET),
    1: (VALID_INDICES[1][1], VALID_INDICES[1][1] + TEST_LENGTH - OFFSET),
    2: (VALID_INDICES[2][1], VALID_INDICES[2][1] + TEST_LENGTH - OFFSET)
}

INDICES = {
    "train": TRAIN_INDICES,
    "valid": VALID_INDICES,
    "test": TEST_INDICES,
}

class Meta(IntEnum):
    ID = 0
    DEVICE_TYPE = 1
    START_ROW = 2
    END_ROW = 3
    NUM_OF_COLS = 4


class PLAIDPowerData(IntEnum):
    APPARENT_POWER = 0
    REAL_POWER = 1
    REACTIVE_POWER = 2
    POWER_FACTOR = 3
    NUM_OF_COLS = 4


class PELData(IntEnum):
    VOLTAGE_RMS = 0
    CURRENT_RMS = 1
    VOLTAGE_CREST_FACTOR = 2
    CURRENT_CREST_FACTOR = 3
    REAL_POWER = 4
    REACTIVE_POWER = 5
    APPARENT_POWER = 6
    POWER_FACTOR = 7
    DIFFERENTIAL_POWER_FACTOR = 8
    TAN_PHI = 9
    VOLTAGE_THD = 10
    CURRENT_THD = 11
    NUM_OF_COLS = 12


class ADE7880Data(IntEnum):
    VOLTAGE_RMS = 0
    CURRENT_RMS = 1
    INSTANTANEOUS_VOLTAGE = 2
    INSTANTANEOUS_CURRENT = 3
    INSTANTANEOUS_ACTIVE_POWER = 4
    INSTANTANEOUS_APPARENT_POWER = 5
    VOLTAGE_THD = 6
    CURRENT_THD = 7
    POWER_FACTOR = 8
    NUM_OF_COLS = 9


class DataSource(IntEnum):
    PLAID = 0
    PEL = 1
    ADE7880 = 2


PEL_data_input_cols = [
    "V1-N (1 s)",
    "I1 (1 s)",
    "V1-N CF (1 s)",
    "I1 CF (1 s)",
    "P1 (W) (1 s)",
    "Q1 (var) (1 s)",
    "S1 (VA) (1 s)",
    "PF1 (1 s)",
    "Cos φ1 (DPF) (1 s)",
    "Tan Φ (1 s)",
    "V1-N THD (1 s)",
    "I1 THD (1 s)"
]

PEL_data_visualization_cols = [
    'Data Instance',
    'Fan ID',
    'Length',
    'Voltage RMS Plot',
    'Current RMS Plot',
    'Voltage Crest Plot',
    'Current Crest Plot',
    'Real Power Plot',
    'Reactive Power Plot',
    'Apparent Power Plot'
    'Power Factor Plot',
    'Differential Power Factor Plot',
    'Tan Phi Plot',
    'Voltage THD Plot',
    'Current THD Plot'
]

ADE7880_input_cols = [
    "AVRMS",
    "AIRMS",
    "VAWV",
    "IAWV",
    "AWATT",
    "AVA",
    "VTHD",
    "ITHD",
    "APF"
]

ADE7880_visualization_cols = [
    'Data Instance',
    'Fan ID',
    'Length',
    'RMS Voltage Plot',
    'RMS Current Plot',
    'Instantaneous Voltage Plot',
    'Instantaneous Current Plot',
    'Instantaneous Active Power Plot',
    'Instantaneous Apparent Power Plot',
    'Voltage THD Plot',
    'Current THD Plot',
    'Power Factor Plot'
]
