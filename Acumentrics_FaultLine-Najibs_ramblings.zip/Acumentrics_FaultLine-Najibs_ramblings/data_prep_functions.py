import os

import numpy as np
import pandas as pd
import sklearn.model_selection as sk_mod


# Splits input CSV into training, validation, and test CSVs based on the given percentages
def split(meta,
          output_path,
          partition_sizes=None):

    if partition_sizes is None:
        partition_sizes = [0.6, 0.2, 0.2]

    # Get partition sizes
    train_size = partition_sizes[0]
    validation_size = partition_sizes[1]
    test_size = partition_sizes[2]

    # Create train partition
    train, temp = sk_mod.train_test_split(meta,
                                          train_size=train_size,
                                          test_size=validation_size + test_size,
                                          stratify=meta[:, 1],  # Used to ensure class balance
                                          shuffle=True)

    # Split remaining partition into validation and test partitions
    validation, test = sk_mod.train_test_split(temp,
                                               train_size=validation_size / (validation_size + test_size),
                                               test_size=test_size / (validation_size + test_size),
                                               stratify=temp[:, 1],  # Used to ensure class balance
                                               shuffle=True)

    # Saves partition output to a CSV
    pd.DataFrame(
        data=train,
        index=list(range(train.shape[0])),
        columns=["ID", "Device Type", "Start Row", "End Row"]
    ).to_csv(os.path.join(output_path, "train.csv"), index=False)

    pd.DataFrame(
        data=validation,
        index=list(range(validation.shape[0])),
        columns=["ID", "Device Type", "Start Row", "End Row"]
    ).to_csv(os.path.join(output_path, "validation.csv"), index=False)

    pd.DataFrame(
        data=test,
        index=list(range(test.shape[0])),
        columns=["ID", "Device Type", "Start Row", "End Row"]
    ).to_csv(os.path.join(output_path, "test.csv"), index=False)

    return train, validation, test


# Checks the percentage of each label within a CSV
def check_balance(labels, name):
    # Gets the unique counts for each device type
    unique_vals, unique_counts = np.unique(labels, return_counts=True)

    # Converts device type counts into percentages
    percentages = unique_counts / labels.shape[0]

    # Prints percentages
    print(f"Class Percentages of {name}: {[f'{unique_vals[i]}: {percentages[i]}' for i in range(len(unique_counts))]}\n")

    return


def min_max_normalization(raw_data, proc_data):
    # min_x = [0] * raw_data.shape[1]
    # max_x = [0] * raw_data.shape[1]

    # Normalization of input data
    for i in range(raw_data.shape[1]):
        min_x, max_x = np.percentile(raw_data[:, i], 5), np.percentile(raw_data[:, i], 95)
        if min_x == max_x:
            proc_data[:, i] = 0.5
        else:
            proc_data[:, i] = (raw_data[:, i] - min_x) / (max_x - min_x)
    return


# def inference_normalization(raw_data, proc_data, min_x, max_x):
#     # Normalization of inference_data
#     for i in range(raw_data.shape[1]):
#         if min_x[i] == max_x[i]:
#             proc_data[:, i] = 0.5
#         else:
#             proc_data[:, i] = (raw_data[:, i] - min_x[i]) / (max_x[i] - min_x[i])
#     return min_x, max_x
