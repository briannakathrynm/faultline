import argparse
import os

import numpy as np
import pandas as pd

import config
import data_prep_functions as dpf
import inference_functions as infunc

if __name__ == "__main__":
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description='Create and Visualize inference output')
    parser.add_argument('--input', '-i', dest='input', default="default",
                        help='Define input directory name in Training Data')
    parser.add_argument('--model', '-m', dest='model', default="default",
                        help='Define directory containing model in Training Results')
    parser.add_argument('--output', '-o', dest='output', default="default",
                        help='Define output directory name in Inference Results')
    parser.add_argument('--PLAID', action='store_true', dest='isPLAID',
                        help='Use PLAID data')
    parser.add_argument('--visualize', action='store_true', dest='isVisualize',
                        help='Visualize output predictions')
    parser.add_argument('--window', action='store', dest='window_length', default=1, type=float,
                        help='Set the length of the data window in seconds (Default: 1')
    args = parser.parse_args()

    input_path = os.path.join(config.TRAINING_DATA_PATH, args.input)
    model_path = os.path.join(config.TRAINING_RESULTS_PATH, args.model, "saved_model")
    output_path = os.path.join(config.INFERENCE_RESULTS_PATH, args.output)

    # Create the Training Run subdirectory
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Read meta CSV data
    meta = pd.read_csv(os.path.join(input_path, "meta.csv")).to_numpy()

    # Determine the number of columns in the power binary
    num_binary_cols = config.PLAIDPowerData.NUM_OF_COLS if args.isPLAID else config.PELData.NUM_OF_COLS

    # Read data from binary file
    data = np.memmap(
        filename=os.path.join(input_path, "total_power.memmap"),
        dtype=np.float64,
        mode="r",
        shape=(meta[meta.shape[0] - 1][config.Meta.END_ROW] + 1, num_binary_cols)
    )

    proc_data = np.memmap(
        filename=os.path.join(output_path, "proc_total_power.memmap"),
        dtype=np.float64,
        mode="w+",
        shape=data.shape
    )

    dpf.min_max_normalization(data, proc_data)

    # Determine the window length
    window_size = int(np.floor(args.window_length * config.INPUT_FREQ)) if args.isPLAID else int(args.window_length)

    infunc.predict(
        binary_col_size=num_binary_cols,
        data=proc_data,
        mapping_path=os.path.join(input_path, "class_mapping.json"),
        meta=meta,
        model_path=model_path,
        output_path=output_path,
        visualize=args.isVisualize,
        window_size=window_size
    )