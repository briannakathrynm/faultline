import tensorflow as tf
import numpy as np
import random as rand

import data_prep_functions as dpf
import config


# Used to generate a batch of data from the ML model
class DataGenerator(tf.keras.utils.Sequence):
    def __init__(
            self,
            num_of_features: int,
            data: np.memmap,
            meta: np.ndarray,
            batch_size: int = 1,
            is_predict: bool = False,
            window_size: int = 180,
            shuffle: bool = False,
            down_sampling_rate: int = 1
    ):
        """

        :param num_of_features:
        :param data:
        :param meta:
        :param batch_size:
        :param is_predict:
        :param window_size:
        :param shuffle:
        """

        # Number of input features
        self.num_of_features = num_of_features
        # Memmap of the input data
        self.data: np.memmap = data
        # Meta data of the memmap (data instance index, label classification, row indices)
        self.meta_data: np.ndarray = meta
        # Model batch size
        self.batch_size: int = batch_size
        # Flag for generating predictions
        self.isPredict = is_predict
        # Shuffle Data after each epoch
        self.shuffle: bool = shuffle
        # Training Indices
        self.indices = np.arange(self.meta_data.shape[0])
        # Number of classes in the input set
        self.num_of_classes = np.unique(self.meta_data[:, config.Meta.DEVICE_TYPE]).shape[0]
        # Number of points within the window
        self.window_size = window_size
        self.down_sampling_rate = down_sampling_rate

        self.class_indices = [np.where(self.meta_data[:, config.Meta.DEVICE_TYPE] == x)[0]
                              for x in np.arange(self.num_of_classes)]
        self.on_epoch_end()

    def __len__(self):
        # Denotes the number of batches per epoch
        return int(np.floor(self.indices.shape[0] / self.batch_size))

    def __getitem__(self, index):
        if self.batch_size < self.num_of_classes:
            return self.__data_generation(
                self.meta_data[
                    self.indices[index * self.batch_size: (index + 1) * self.batch_size]
                ]
            )
        else:
            class_batch: int = (self.batch_size // self.num_of_classes)
            meta_data_sub = np.vstack(
                [self.meta_data[self.class_indices[class_type][index * class_batch: (index + 1) * class_batch]]
                 for class_type in np.arange(self.num_of_classes)]
            )
            np.random.shuffle(meta_data_sub)
            return self.__data_generation(meta_data_sub)

    def on_epoch_end(self):
        # Update after each epoch
        self.indices = np.arange(self.meta_data.shape[0])
        self.class_indices = [np.where(self.meta_data[:, config.Meta.DEVICE_TYPE] == x)[0]
                              for x in np.arange(self.num_of_classes)]
        if self.shuffle:
            np.random.shuffle(self.indices)
            for i in range(len(self.class_indices)):
                np.random.shuffle(self.class_indices[i])
        return

    def __data_generation(self, meta_data_sub):
        # Generate arrays containing a batch of input data
        x = np.zeros(shape=(meta_data_sub.shape[0], self.window_size // self.down_sampling_rate, self.num_of_features), dtype=np.float64)
        y = np.zeros(shape=(meta_data_sub.shape[0], ), dtype=np.int8)

        # x[:], y[:] = np.nan, np.nan

        for i, meta_row in enumerate(meta_data_sub):
            start_row, end_row = meta_row[config.Meta.START_ROW], meta_row[config.Meta.END_ROW]
            data_length = end_row - start_row + 1

            if data_length < 180:
                raise ValueError(f'window too small: {data_length}')
            # Get random initial index of the window within the data instance
            if data_length - self.window_size > 0:  # start off at random index in instance
                start_index = rand.randrange(data_length - self.window_size)
                end_index = start_index + self.window_size + 1
            elif data_length == self.window_size:  # take full instance
                start_index = 0
                end_index = data_length + 1
            else:
                raise ValueError(f'window too small: {data_length}')

            # Append the window data
            x[i] = self.data[start_row: end_row + 1, start_index: end_index: self.down_sampling_rate]

            # Append the label
            y[i] = meta_row[config.Meta.DEVICE_TYPE]

        x_problems, y_problems = np.where(x == np.nan), np.where(y == np.nan)

        return x, y


