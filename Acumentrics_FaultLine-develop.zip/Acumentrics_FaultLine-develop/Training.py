import os
from datetime import datetime
from shutil import copyfile

import numpy as np
import tensorflow as tf
# noinspection PyUnresolvedReferences
import tensorflow.keras as keras
# noinspection PyUnresolvedReferences
import tensorflow.keras.models as models
import json
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt

import DataGenerator
import config
import data_prep_functions as dpf


class Training:
    def __init__(self,
                 num_of_features: int,
                 data: np.memmap,
                 epochs: int,
                 input_path: str,
                 meta: np.ndarray,
                 output_path: str,
                 batch_size: int = 1,
                 part_sizes: list = None,
                 visualize: bool = False,
                 verbose: bool = False,
                 window_size: int = 180,
                 down_sampling_rate: int = 1):
        """

        :param num_of_features:
        :param data:
        :param epochs:
        :param input_path:
        :param meta:
        :param output_path:
        :param batch_size:
        :param part_sizes:
        :param visualize:
        :param verbose:
        :param window_size:
        """

        self.raw_data: np.memmap = data
        self.batch_size: int = batch_size
        self.num_of_features: int = num_of_features
        self.epochs: int = epochs
        self.meta: np.ndarray = meta
        self.model = None
        self.output_path: str = output_path
        self.part_sizes: list = part_sizes if part_sizes else [0.6, 0.3, 0.1]

        if not os.path.exists(self.output_path):
            os.makedirs(self.output_path)
        self.proc_data = np.memmap(filename=os.path.join(self.output_path, "proc_total_power.memmap"),
                                   dtype=np.float64,
                                   mode="w+",
                                   shape=self.raw_data.shape)
        self.test_set = None
        self.train_set = None
        self.validation_set = None
        self.visualize: bool = visualize
        self.verbose: bool = verbose
        self.window_size: int = window_size
        self.down_sampling_rate = down_sampling_rate

        # Check for valid partition sizes
        for item in self.part_sizes:
            if not item >= 0:
                raise ValueError(f"Invalid Partition Size.\nGiven {self.part_sizes}")
        else:
            if not round(sum(self.part_sizes), 1) == 1:
                raise ValueError(f"Invalid Partition Sizes.\nGiven {self.part_sizes}")

        # Create output directory
        if not os.path.isdir(self.output_path):
            os.makedirs(self.output_path)

        # Normalize input data
        dpf.min_max_normalization(self.raw_data, self.proc_data)

        copyfile(os.path.join(input_path, "total_power.memmap"), os.path.join(self.output_path, "total_power.memmap"))
        copyfile(os.path.join(input_path, "class_mapping.json"), os.path.join(self.output_path, "class_mapping.json"))
        copyfile(os.path.join(input_path, "meta.csv"), os.path.join(self.output_path, "meta.csv"))

        print("Successfully created the Training Object")
        return

    def build(self):

        activation = 'sigmoid'

        # Create model structure
        self.model = keras.Sequential([
            keras.layers.InputLayer(input_shape=(self.window_size, self.num_of_features)),
            keras.layers.LSTM(units=32, activation=activation, ),
            keras.layers.BatchNormalization(),
            keras.layers.Dropout(rate=0.5),
            keras.layers.Flatten(),
            # keras.layers.Dense(units=16, activation=activation, activity_regularizer=keras.regularizers.l2(0.1), ),
            # keras.layers.BatchNormalization(),
            # keras.layers.Dropout(rate=0.5),
            keras.layers.Dense(units=16, activation=activation, ),
            keras.layers.BatchNormalization(),
            keras.layers.Dropout(rate=0.5),
            keras.layers.Dense(units=np.unique(self.meta[:, 1]).size, activation='softmax')
        ])
        self.model.summary()

        if self.visualize:
            # Visualize current model
            tf.keras.utils.plot_model(
                self.model,
                os.path.join(self.output_path, "model_structure.png"),
                show_shapes=True
            )

        # Compile the model
        self.model.compile(
            optimizer='adam',
            loss='sparse_categorical_crossentropy',
            metrics=['accuracy'],
        )

        print("Successfully built the model")
        return

    def train(self):
        # Split the dataset into training, validation, and test datasets
        self.train_set, self.validation_set, self.test_set = dpf.split(
            meta=self.meta,
            output_path=self.output_path,
            partition_sizes=self.part_sizes
        )

        if self.verbose:
            # Print the class balances of the datasets
            dpf.check_balance(self.train_set[:, config.Meta.DEVICE_TYPE], "Train")
            dpf.check_balance(self.validation_set[:, config.Meta.DEVICE_TYPE], "Validation")
            dpf.check_balance(self.test_set[:, config.Meta.DEVICE_TYPE], "Test")

        # Create generators for each dataset
        train_gen = DataGenerator.DataGenerator(
            num_of_features=self.num_of_features,
            data=self.proc_data,
            meta=self.train_set,
            batch_size=self.batch_size,
            window_size=self.window_size,
            down_sampling_rate=self.down_sampling_rate,
            shuffle=True
        )

        validation_gen = DataGenerator.DataGenerator(
            num_of_features=self.num_of_features,
            data=self.proc_data,
            meta=self.validation_set,
            batch_size=self.batch_size,
            window_size=self.window_size,
            down_sampling_rate=self.down_sampling_rate,
            shuffle=True
        )

        # noinspection PyUnusedLocal
        log_dir = "logs/" + datetime.now().strftime("%Y%m%d-%H%M%S")
        # tb_callback = tf.keras.callbacks.TensorBoard(log_dir=log_dir, histogram_freq=1, write_images=True,
        #                                              update_freq='batch', write_grads=True, write_graph=True)
        nan_callback = keras.callbacks.TerminateOnNaN()
        early_stopper = keras.callbacks.EarlyStopping(
            monitor='val_loss',
            min_delta=0.0001,
            patience=16,
            verbose=1,
            restore_best_weights=True
        )
        callbacks = [
            nan_callback,
            early_stopper,
        ]

        # Train the model on the train and validation sets
        self.model.fit(
            x=train_gen,
            epochs=self.epochs,
            verbose=int(self.verbose),
            callbacks=callbacks,
            validation_data=validation_gen,
            initial_epoch=0,
        )

        print("Successfully trained the model")
        return

    def evaluate(self):

        # Create generator for test dataset
        test_gen = DataGenerator.DataGenerator(
            num_of_features=self.num_of_features,
            data=self.proc_data,
            meta=self.test_set,
            batch_size=self.batch_size,
            window_size=self.window_size,
            down_sampling_rate=self.down_sampling_rate,
            shuffle=True
        )

        # Evaluate the model with the test dataset
        self.model.evaluate(
            x=test_gen,
            verbose=int(self.verbose),
        )

        print("Successfully evaluated the model")
        return

    def load(self,
             model_path: str):

        # Load model from given file path
        self.model = models.load_model(model_path)

        print("Successfully loaded the model")
        return

    def save(self):
        # Make the sub-directory for the saved model
        saved_model_path = os.path.join(self.output_path, "saved_model")
        if not os.path.isdir(saved_model_path):
            os.mkdir(saved_model_path)

        # Save the model in the subdirectory
        # noinspection PyUnresolvedReferences
        tf.saved_model.save(self.model, saved_model_path)

        # Save the model in output directory
        self.model.save(os.path.join(self.output_path, "model.h5"))

        print("Successfully saved the model")
        return

    def export(self):
        # noinspection PyUnresolvedReferences
        converter = tf.lite.TFLiteConverter.from_keras_model(self.model)
        converter.experimental_new_converter = True
        converter.allow_custom_ops = True
        tflite_model = converter.convert()
        open("converted_model.tflite", "wb").write(tflite_model)

        print("Successfully exported the model")
        return

    def inference(self, inference_path):

        inference_meta = pd.read_csv(os.path.join(inference_path, "meta.csv")).to_numpy()

        # Read data from binary file
        raw_inference_data = np.memmap(
            filename=os.path.join(inference_path, "total_power.memmap"),
            dtype=np.float64,
            mode="r",
            shape=(inference_meta[inference_meta.shape[0] - 1][config.Meta.END_ROW] + 1, self.num_of_features)
        )

        proc_inference_data = np.memmap(
            filename=os.path.join(inference_path, "proc_total_power.memmap"),
            dtype=np.float64,
            mode="w+",
            shape=raw_inference_data.shape
        )

        # Normalize input data
        dpf.min_max_normalization(raw_inference_data, proc_inference_data)

        # Create generator for test dataset
        predict_generator = DataGenerator.DataGenerator(
            num_of_features=self.num_of_features,
            data=proc_inference_data,
            meta=inference_meta,
            batch_size=1,
            window_size=self.window_size,
            down_sampling_rate=self.down_sampling_rate,
            shuffle=False
        )

        nan_callback = keras.callbacks.TerminateOnNaN()

        # Evaluate the model with the test dataset
        self.model.evaluate(
            x=predict_generator,
            verbose=int(self.verbose),
        )

        # Predict on data
        predictions = self.model.predict(
            x=predict_generator,
            verbose=1,
            callbacks=[nan_callback]
        )

        mapping_path = os.path.join(self.output_path, "class_mapping.json")

        with open(mapping_path, 'r') as json_file:
            class_mapping = json.load(json_file)

        # Determine individual class accuracy & total accuracy
        class_acc = np.zeros(len(class_mapping.keys()))
        class_counts = np.zeros(len(class_mapping.keys()))

        for prediction, label in zip(np.argmax(predictions, axis=1), inference_meta[:, config.Meta.DEVICE_TYPE]):
            print(f"Prediction: {prediction} => {label}")
            class_counts[label] += 1
            if prediction == label:
                class_acc[label] += 1

        total_acc = np.sum(class_acc) / np.sum(class_counts)
        class_acc /= class_counts

        # Print results
        print(f"\n"
              f"Results:",
              f"{[f'{class_type}:{class_acc[value]}' for class_type, value in class_mapping.items()]}",
              f"Total Accuracy: {total_acc}\n",
              sep="\n")

        # Produce a bar graph visualization for each data instance
        if True:
            # Set style for plots
            sns.set_style("dark")

            # Make visualization graphs
            for idx, pred in enumerate(predictions):
                data = {'Classes': list(class_mapping.keys()), 'Predictions': pred}
                my_df = pd.DataFrame(data)
                plot = sns.barplot(x='Classes', y='Predictions', data=my_df)
                fig = plot.get_figure()
                fig.savefig(self.output_path + "/" + str(inference_meta[idx][config.Meta.ID]), dpi=700)
                plt.close()
