import json
import os
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import tensorflow.keras as keras

import config

import DataGenerator


def predict(
        binary_col_size: int,
        data: np.memmap,
        mapping_path: str,
        meta: np.array,
        model_path: str,
        output_path: str,
        visualize: bool,
        window_size: int
):

    # Create DataGenerator
    predict_generator = DataGenerator.DataGenerator(
        num_of_features=binary_col_size,
        data=data,
        meta=meta,
        batch_size=1,
        is_predict=True,
        window_size=window_size,
        shuffle=False
    )

    model = keras.models.load_model(model_path)

    nan_callback = keras.callbacks.TerminateOnNaN()

    # Predict on data
    predictions = model.predict(
        x=predict_generator,
        verbose=1,
        callbacks=[nan_callback]
    )

    with open(mapping_path, 'r') as json_file:
        class_mapping = json.load(json_file)

    # Determine individual class accuracy & total accuracy
    class_acc = np.zeros(len(class_mapping.keys()))
    class_counts = np.zeros(len(class_mapping.keys()))

    for prediction, label in zip(np.argmax(predictions, axis=1), meta[:, config.Meta.DEVICE_TYPE]):
        print(f"Prediction\Label: {prediction} => {label}")
        class_counts[label] += 1
        if prediction == label:
            class_acc[label] += 1

    total_acc = np.sum(class_acc) / np.sum(class_counts)
    class_acc /= class_counts

    # Print results
    print(f"\n"
          f"Results:",
          f"{[f'{class_type}:{class_acc[value]}' for class_type, value in class_mapping.items()]}",
          f"Total Accuracy: {total_acc}\n",
          sep="\n")

    # Produce a bar graph visualization for each data instance
    if visualize:
        # Set style for plots
        sns.set_style("dark")

        # Make visualization graphs
        for idx, pred in enumerate(predictions):
            data = {'Classes': list(class_mapping.keys()), 'Predictions': pred}
            my_df = pd.DataFrame(data)
            plot = sns.barplot(x='Classes', y='Predictions', data=my_df)
            fig = plot.get_figure()
            fig.savefig(output_path + "/" + str(meta[idx][config.Meta.ID]), dpi=700)
            plt.close()

    return
