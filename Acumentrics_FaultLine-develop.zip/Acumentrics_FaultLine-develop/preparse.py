import argparse
import os.path as path
import sys

import config
import preparse_functions as pp

if __name__ == "__main__":
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description='Preprocess CSV data into binary data')
    parser.add_argument('--source', '-s', dest='data_source', required=True, type=int,
                        help='Data source of the input data')
    parser.add_argument('--input', '-i', action='store', dest='input', default='default',
                        help='Define input directory name in Raw Data')
    parser.add_argument('--output', '-o', action='store', dest='output', default='default',
                        help='Define output directory name in Training Data')
    parser.add_argument('--visualize', action='store_true', dest='isVisualized',
                        help='Produces visualizations for input data')
    parser.add_argument('-d', nargs='+', dest='devices',
                        help='List of device types to be processed. If no type is provided, all device types are processed')
    parser.add_argument('--class', action='store', dest='class_mapping',
                        help='Define a directory for a class mapping')
    args = parser.parse_args()

    # Check for valid data source
    if args.data_source < 0 or args.data_source > 2:
        print("Invalid data source type (See config for full list of sources")
        sys.exit(1)

    pp.preparse(
        data_source=args.data_source,
        input_path=path.join(config.RAW_DATA_PATH, args.input),
        output_path=path.join(config.TRAINING_DATA_PATH, args.output),
        visualize=args.isVisualized,
        devices=args.devices,
        class_mapping_path=args.class_mapping
    )
