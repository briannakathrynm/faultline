import json
import os
from typing import Dict, List

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

import config


# Based on the given DataFrame, generates a plot of the "x" column and "y" column in the given color that will be saved
# as the given image_path.
def gen_save_figure(
        x_name,
        y_name,
        df,
        image_path,
        color_name="black",
        plot_type="scatter",
):
    # Set style for plots
    sns.set_style("dark")

    # Add index column
    df["Index"] = range(0, df.shape[0])

    if plot_type == "line":
        plot = sns.lineplot(x=x_name, y=y_name, data=df, linewidth=1, color=color_name)
    elif plot_type == "scatter":
        plot = sns.scatterplot(x=x_name, y=y_name, data=df, s=3, marker=".", linewidth=0, color=color_name)
    else:
        return
    fig = plot.get_figure()
    fig.savefig(image_path)
    plt.close()
    return


# noinspection PyPep8Naming
def generate_PLAID_binary(output_path, visualize, devices):
    # DataFrame containing the power data for all instances
    total_power_df = pd.DataFrame(columns=["Apparent Power",
                                           "Real Power",
                                           "Reactive Power",
                                           "Power Factor"])

    # DataFrame containing the meta data for the power data
    total_power_meta_df = pd.DataFrame(columns=["ID",
                                                "Device Type",
                                                "Start Row",
                                                "End Row"])

    # Classification mapping dictionary
    class_mapping = {}

    # Generates a directory of images and CSV files for PLAID
    for file in os.listdir(config.PLAID_PATH):
        if file.endswith(".json"):
            # Load each json file
            with open(config.PLAID_PATH + file, 'r') as json_file:
                meta = json.load(json_file)

            # Repeat for selected devices in the json file
            for dset in meta:
                if not devices or dset["meta"]["type"] in devices:

                    # Read the data instance CSV
                    input_CSV_path = config.PLAID_PATH + "CSV/" + dset["id"] + ".csv"
                    input_df = pd.read_csv(input_CSV_path, names=["Current", "Voltage"])

                    # Add additional columns to the DataFrame
                    time = [val * (1 / config.SAMPLING_FREQ) for val in range(0, input_df.shape[0])]

                    input_df["Time"] = pd.Series(time)
                    input_df["Power"] = input_df["Current"] * input_df["Voltage"]

                    # Calculate the number of cycles of the voltage/current waves
                    points_per_cycle = config.SAMPLING_FREQ // config.INPUT_FREQ
                    number_of_periods = int(input_df.shape[0] // points_per_cycle)

                    # Create the initial power DataFrame
                    power_df = pd.DataFrame(columns=["Apparent Power",
                                                     "Real Power",
                                                     "Reactive Power",
                                                     "Power Factor"])

                    # Calculate power parameters for each cycle
                    for i in range(0, number_of_periods):
                        # Get one period of data from the larger dataset
                        voltage_set = input_df["Voltage"].to_numpy()[
                                      i * points_per_cycle: i * points_per_cycle + points_per_cycle]
                        current_set = input_df["Current"].to_numpy()[
                                      i * points_per_cycle: i * points_per_cycle + points_per_cycle]

                        # Calculate the RMS value and index for both current and voltage
                        V_rms = np.amax(voltage_set) / np.sqrt(2)
                        I_rms = np.amax(current_set) / np.sqrt(2)

                        v_max_index = np.argmax(voltage_set)
                        curr_max_index = np.argmax(current_set)

                        # Calculate the phase shift between current and voltage
                        time_delay = abs(curr_max_index - v_max_index) / config.SAMPLING_FREQ
                        phase_shift = 2 * np.pi * config.INPUT_FREQ * time_delay

                        # Calculate the complex power components
                        app_power = V_rms * I_rms
                        real_power = app_power * np.cos(phase_shift)
                        react_power = app_power * np.sin(phase_shift)
                        power_factor = np.cos(phase_shift)

                        # Append the power value to the power dataset
                        power_df = power_df.append({'Apparent Power': app_power,
                                                    'Real Power': real_power,
                                                    'Reactive Power': react_power,
                                                    'Power Factor': power_factor}, ignore_index=True)

                    # If an appliance does not already have a label, add label to dictionary
                    if not dset["meta"]["type"] in class_mapping:
                        class_mapping[dset["meta"]["type"]] = len(class_mapping)

                    # Append power meta data
                    total_power_meta_df = total_power_meta_df.append({"ID": dset["id"],
                                                                      "Device Type": class_mapping[dset["meta"]["type"]],
                                                                      "Start Row": total_power_df.shape[0],
                                                                      "End Row": total_power_df.shape[0] + power_df.shape[0] - 1},
                                                                     ignore_index=True)

                    # Append data instance to full power DataFrame
                    total_power_df = total_power_df.append(power_df, ignore_index=True)

                    # Generate Images
                    if visualize:
                        # If appliance directory does not exist, create one
                        image_app_path = output_path + "Images/" + dset["meta"]["type"] + "/"
                        if not os.path.isdir(image_app_path):
                            os.mkdir(image_app_path)
                            empty_df = pd.DataFrame(columns=['Id',
                                                             'Collection Time',
                                                             'Sampling Frequency',
                                                             'Location',
                                                             'Length',
                                                             'Voltage Plot',
                                                             'Current Plot',
                                                             'Instantaneous Power Plot',
                                                             'Apparent Power',
                                                             'Real Power',
                                                             'Reactive Power',
                                                             'Power Factor'])
                            empty_df.to_csv(image_app_path + dset["meta"]["type"] + ".csv", index=False)

                        # Create instance subdirectory
                        id_path = image_app_path + dset["id"] + "/"
                        if not os.path.isdir(id_path):
                            os.mkdir(id_path)

                        # Generate and save plots
                        gen_save_figure(x_name="Time",
                                        y_name="Current",
                                        df=input_df,
                                        image_path=id_path + "Current.png",
                                        color_name="blue")
                        gen_save_figure(x_name="Time",
                                        y_name="Voltage",
                                        df=input_df,
                                        image_path=id_path + "Voltage.png",
                                        color_name="red")
                        gen_save_figure(x_name="Time",
                                        y_name="Power",
                                        df=input_df,
                                        image_path=id_path + "Instant_Power.png")
                        gen_save_figure(x_name="Index",
                                        y_name="Apparent Power",
                                        df=power_df,
                                        image_path=id_path + "Apparent_Power.png",
                                        plot_type="line")
                        gen_save_figure(x_name="Index",
                                        y_name="Real Power",
                                        df=power_df,
                                        image_path=id_path + "Real_Power.png",
                                        plot_type="line")
                        gen_save_figure(x_name="Index",
                                        y_name="Reactive Power",
                                        df=power_df,
                                        image_path=id_path + "Reactive_Power.png",
                                        plot_type="line")
                        gen_save_figure(x_name="Index",
                                        y_name="Power Factor",
                                        df=power_df,
                                        image_path=id_path + "Power_Factor.png",
                                        plot_type="line")

                        # Append to the appliance CSV file
                        app_df = pd.read_csv(image_app_path + dset["meta"]["type"] + ".csv")
                        app_df = app_df.append({'Id': dset["id"],
                                                'Collection Time': dset["meta"]["header"]["collection_time"],
                                                'Sampling Frequency': dset["meta"]["header"]["sampling_frequency"],
                                                'Location': dset["meta"]["location"],
                                                'Length': dset["meta"]["instances"]["length"],
                                                'Voltage Plot': os.getcwd() + id_path[1:] + "Voltage.png",
                                                'Current Plot': os.getcwd() + id_path[1:] + "Current.png",
                                                'Instantaneous Power Plot': os.getcwd() + id_path[
                                                                                          1:] + "Instant_Power.png",
                                                'Apparent Power': os.getcwd() + id_path[1:] + "Apparent_Power.png",
                                                'Real Power': os.getcwd() + id_path[1:] + "Real_Power.png",
                                                'Reactive Power': os.getcwd() + id_path[1:] + "Reactive_Power.png",
                                                'Power Factor': os.getcwd() + id_path[1:] + "Power_Factor.png"},
                                               ignore_index=True)
                        app_df.to_csv(image_app_path + dset["meta"]["type"] + ".csv", index=False)

                    print("Finished with " + dset["id"])

    return total_power_df, total_power_meta_df, class_mapping


def generate_fan_binary(
        class_mapping, # FIXME: Check what type the class_mapping is (i.e. what does json.load return)
        input_path: str,
        output_path: str,
        data_source: config.DataSource,
        visualize: bool):

    # Read classification CSV
    classification_df = pd.read_csv(os.path.join(input_path, "classification.csv"))
    instances = classification_df["ID"].to_numpy(dtype=int)

    # Create DataFrame to contain all power data
    data_input_cols = config.PEL_data_input_cols if data_source == config.DataSource.PEL else config.ADE7880_input_cols
    total_power_df = pd.DataFrame(columns=data_input_cols)

    # DataFrame containing the meta data for the power data
    total_power_meta_df = pd.DataFrame(columns=["ID",
                                                "Device Type",
                                                "Start Row",
                                                "End Row"])

    # Classification mapping dictionary
    if not class_mapping:
        classes = set([t for t in classification_df["Type"].values])  # {'Good', 'Bad'}
        class_mapping = {c: i for i, c in enumerate(classes)}  # {'Good': 0, 'Bad': 1}

    for i, (instance, label) in enumerate(zip(instances, classification_df["Type"].values)):
        power_df = pd.read_csv(os.path.join(input_path, str(instance) + ".csv"))

        # Append power meta data
        total_power_meta_df = total_power_meta_df.append({"ID": instance,
                                                          "Device Type": class_mapping[label],
                                                          "Start Row": total_power_df.shape[0],
                                                          "End Row": total_power_df.shape[0] + power_df.shape[0] - 1},
                                                         ignore_index=True)

        # Append data instance to full power DataFrame
        total_power_df = total_power_df.append(power_df, ignore_index=True)

        # Generate Images
        if visualize:
            # If appliance directory does not exist, create one
            image_fault_path = output_path + "Images/" + label + "/"
            if not os.path.isdir(image_fault_path):
                os.mkdir(image_fault_path)

                # Generate CSV Header for plots
                plot_input_cols = config.PEL_data_visualization_cols if data_source == config.DataSource.PEL else config.ADE7880_visualization_cols
                image_df = pd.DataFrame(columns=plot_input_cols)
                image_df.to_csv(image_fault_path + label + ".csv", index=False)

            # Create instance subdirectory
            id_path = image_fault_path + str(instance) + "/"
            if not os.path.isdir(id_path):
                os.mkdir(id_path)

            # Generate and save plots
            for col in data_input_cols:
                gen_save_figure(x_name="Index",
                                y_name=col,
                                df=power_df,
                                image_path=id_path + col,
                                plot_type="line")

            # Append to the appliance CSV file
            app_df = pd.read_csv(image_fault_path + label + ".csv")

            if data_source == config.DataSource.PEL:
                app_df = app_df.append({'Data Instance': str(instance),
                                        'Fan ID': label,
                                        'Length': power_df.shape[0],
                                        'Voltage RMS Plot': os.getcwd() + id_path[1:] + "V1-N (1 s)",
                                        'Current RMS Plot': os.getcwd() + id_path[1:] + "I1 (1 s)",
                                        'Voltage Crest Plot': os.getcwd() + id_path[1:] + "V1-N CF (1 s)",
                                        'Current Crest Plot': os.getcwd() + id_path[1:] + "I1 CF (1 s)",
                                        'Real Power Plot': os.getcwd() + id_path[1:] + "P1 (W) (1 s)",
                                        'Reactive Power Plot': os.getcwd() + id_path[1:] + "Q1 (var) (1 s)",
                                        'Apparent Power Plot': os.getcwd() + id_path[1:] + "S1 (var) (1 s)",
                                        'Power Factor Plot': os.getcwd() + id_path[1:] + "PF1 (1 s)",
                                        'Differential Power Factor Plot': os.getcwd() + id_path[
                                                                                        1:] + "Cos φ1 (DPF) (1 s)",
                                        'Tan Phi Plot': os.getcwd() + id_path[1:] + "Tan Φ (1 s)",
                                        'Voltage THD Plot': os.getcwd() + id_path[1:] + "V1-N THD (1 s)",
                                        'Current THD Plot': os.getcwd() + id_path[1:] + "I1 THD (1 s)"},
                                       ignore_index=True)
            else:
                app_df = app_df.append({'Data Instance': str(instance),
                                        'Fan ID': label,
                                        'Length': power_df.shape[0],
                                        'Voltage RMS Plot': os.getcwd() + id_path[1:] + "AVRMS",
                                        'Current RMS Plot': os.getcwd() + id_path[1:] + "AIRMS",
                                        'Instantaneous Voltage Plot': os.getcwd() + id_path[1:] + "VAWV",
                                        'Instantaneous Current Plot': os.getcwd() + id_path[1:] + "IAWV",
                                        'Instantaneous Active Power Plot': os.getcwd() + id_path[1:] + "AWATT",
                                        'Instantaneous Apparent Power Plot': os.getcwd() + id_path[1:] + "AVA",
                                        'Voltage THD Plot': os.getcwd() + id_path[1:] + "VTHD",
                                        'Current THD Plot': os.getcwd() + id_path[1:] + "ITHD",
                                        'Power Factor Plot': os.getcwd() + id_path[1:] + "APF"},
                                       ignore_index=True)
            app_df.to_csv(image_fault_path + label + ".csv", index=False)

        print("Finished with " + str(instance))

    return total_power_df, total_power_meta_df, class_mapping


def preparse(
        data_source: config.DataSource,
        input_path: str,
        output_path: str,
        visualize: bool,
        devices: List[str],
        class_mapping_path: str
):
    # Generate a directory for the power data output
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Generate a directory for the image output
    images_path = os.path.join(output_path, "Images/")
    if not os.path.isdir(images_path) and visualize:
        os.makedirs(images_path)

    # Read class mapping
    if class_mapping_path:
        with open(os.path.join(config.TRAINING_DATA_PATH, class_mapping_path, "class_mapping.json"), 'r') as json_file:
            class_mapping = json.load(json_file)
    else:
        class_mapping = None

    # Convert raw data to binary data
    if data_source == config.DataSource.PLAID:
        total_power_df, total_power_meta_df, class_mapping = generate_PLAID_binary(output_path,
                                                                                   visualize,
                                                                                   devices)
    else:
        total_power_df, total_power_meta_df, class_mapping = generate_fan_binary(class_mapping,
                                                                                 input_path,
                                                                                 output_path,
                                                                                 data_source,
                                                                                 visualize)

    # Write the power meta data to CSV
    total_power_meta_df.to_csv(os.path.join(output_path, "meta.csv"), index=False)

    # Create a binary file for storage of power data
    fp = np.memmap(filename=os.path.join(output_path, "total_power.memmap"),
                   dtype=np.float64,
                   mode="w+",
                   shape=total_power_df.shape)

    # Copy power data into binary memory
    fp[:] = total_power_df.to_numpy()[:]

    # Flush data to memory
    del fp

    # Write class mapping to JSON file
    with open(os.path.join(output_path, "class_mapping.json"), "w") as json_file:
        json.dump(class_mapping, json_file)

    return


# Converts Fan Excel Data or ADE7880 CSV Data to classification CSV & data CSVs
def splitter(
        data_source: config.DataSource,
        fault_type: str,
        input_path: str,
        output_path: str,
        instance_length: int,
        append_data: bool
):
    # Create Output Directory
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Read/Create classification CSV
    if append_data:
        class_df = pd.read_csv(os.path.join(output_path, "classification.csv"))
        current_index = class_df.shape[0] + 1
    else:
        class_df = pd.DataFrame(columns=['ID', 'Type'])
        current_index = 1

    for file in os.listdir(input_path):
        # Get full path to file
        file_path = os.path.join(input_path, file)

        power_df = None
        if file.endswith('.xlsx') and data_source == config.DataSource.PEL:
            power_df = pd.read_excel(io=file_path,
                                     sheet_name=3,
                                     usecols=config.PEL_data_input_cols,
                                     skiprows=[0, 2])

        elif file.endswith('.csv') and data_source == config.DataSource.ADE7880:
            power_df = pd.read_csv(file_path, usecols=config.ADE7880_input_cols, index_col=False)

        else:
            print("Invalid file name")
            return

        for i in range(0, power_df.shape[0] // instance_length):
            bad_data = False

            part_df = power_df.iloc[i * instance_length: (i * instance_length) + instance_length]

            for col in part_df:
                if part_df[col].astype(str).str.contains('- - -').any():
                    bad_data = True
                    break

            if not bad_data:
                # Write sub-section of data file to CSV
                part_df.to_csv(os.path.join(output_path, str(current_index) + ".csv"), index=False)

                # Update classification CSV
                class_df = class_df.append({'ID': current_index,
                                            'Type': fault_type},
                                           ignore_index=True)
                print("Finished with " + str(current_index))

                current_index += 1

    # Write the classification CSV
    class_df.to_csv(os.path.join(output_path, "classification.csv"), index=False)
    return
