import subprocess
import sys
import typing

import numpy as np
import pandas as pd
import tensorflow.keras as keras
from gpiozero import LED

import config

# Initializes output LEDs
# FIXME: Once a proper interface is added to custom PCB, update this configuration
inference_LED: LED = LED(15)
fault_LEDs: typing.List[LED] = [LED(13), LED(17), LED(25)]

previous_prediction: int = 1
inference_LED.on()
fault_LEDs[previous_prediction].on()

# FIXME: Refactor these variables into command-line arguments
model_path: str = "/home/pi/scrap/real_time_inference/model.h5"
data_freq: str = "2000"
window_length: str = "18000"
output_file: str = "inference_data"

# Stores the normalization ranges for the ML features
# FIXME: Ranges should either be stored by the training process or an alternative normalization process
#  should be utilized
min_x: typing.List[float] = [1291497.0, 161018.0, -1753393.0, -231508.0, -25577.0, 24877.0, 92146.0, 154913.0, -32153.0]
max_x: typing.List[float] = [1302410.0, 168784.0, 1757789.0, 231604.0, -24399.0, 26194.0, 105773.0, 178866.0, -31966.0]

# Initializes callback for inference process to terminate on "nan" value
# FIXME: Callback may be unnecessary for inference process
nan_callback = keras.callbacks.TerminateOnNaN()

# Load the ML model
model: keras.models.Model = keras.models.load_model(model_path)

# Start the data collection program
proc: subprocess.Popen = subprocess.Popen(
    ["./collect_data", data_freq, window_length, output_file, "1"],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT
)

# FIXME: Use "logging" module to print out status messages
print("Running...")

while True:
    try:
        # Start collecting data from ADE7880
        proc.stdin.write("collect\n".encode())
        proc.stdin.flush()

        # Wait for data collection process to complete
        output: str = proc.stdout.readline().decode().rstrip()

        # Read ADE7880 data from CSV
        raw_data: np.ndarray = pd.read_csv(
            output_file + ".csv",
            index_col=False,
            usecols=config.ADE7880_input_cols
        ).to_numpy()

        # Normalize ADE7880 data
        norm_data: np.ndarray = np.zeros(shape=raw_data.shape)
        for i in range(raw_data.shape[1]):
            if min_x[i] == max_x[i]:
                norm_data[:, i] = 0.5
            else:
                norm_data[:, i] = (raw_data[:, i] - min_x[i]) / (max_x[i] - min_x[i])

        # Convert 2D array into 3D array for model input
        model_input: np.ndarray = np.expand_dims(norm_data, axis=0)

        # Predict on inference data
        predictions: np.ndarray = model.predict(
            x=model_input,
            verbose=1,
            callbacks=[nan_callback]
        )

        # FIXME: Use "logging" module to print out status messages
        print(predictions)

        prediction: int = int(np.argmax(predictions))

        # FIXME: Use "logging" module to print out status messages
        print(prediction)

        # Update output LEDs
        if previous_prediction != prediction:
            fault_LEDs[previous_prediction].off()
            fault_LEDs[prediction].on()
            previous_prediction = prediction

    except KeyboardInterrupt:
        # Turn off all LEDs
        inference_LED.off()
        for LED in fault_LEDs:
            LED.off()
        sys.exit(0)
