import argparse
import os.path as path
import sys

import config
import preparse_functions as pp


if __name__ == "__main__":
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description='Split excels into CSVs')
    parser.add_argument('--source', '-s', dest='data_source', required=True, type=int,
                        help='Data source of the input data')
    parser.add_argument('--fault_type', '-f', dest='fault_type', required=True,
                        help='Fault type of the input data')
    parser.add_argument('--input', '-i', dest='input_path', required=True,
                        help='Define input directory path for excel data')
    parser.add_argument('--output', '-o', dest='output_path', default="default",
                        help='Define output directory name in Raw Data')
    parser.add_argument('--instance_length', '-l', dest='instance_length', required=True, type=int,
                        help='Output Partition Size')
    parser.add_argument('--append', '-a', action="store_true", dest='isAppend',
                        help='Append to classification CSV in output directory')
    args = parser.parse_args()

    # Check for valid data source
    if args.data_source < 0 or args.data_source > 2:
        print("Invalid data source type (See config for full list of sources")
        sys.exit(1)

    pp.splitter(
        data_source=args.data_source,
        fault_type=args.fault_type,
        input_path=args.input_path,
        output_path=path.join(config.RAW_DATA_PATH, args.output_path),
        instance_length=args.instance_length,
        append_data=args.isAppend
    )
