import tensorflow as tf
import numpy as np
import random as rand

import config


# Used to generate a batch of data from the ML model
class DataGenerator(tf.keras.utils.Sequence):
    def __init__(self,
                 data: np.memmap,
                 meta: np.ndarray,
                 batch_size: int = 32,
                 window_size: int = 1,
                 shuffle: bool = False):

        # Memmap of the input data
        self.data: np.memmap = data
        # Meta data of the memmap (data instance index, label classification, row indices)
        self.meta_data: np.ndarray = meta
        # Model Batch Size
        self.batch_size: int = batch_size
        # Shuffle Data after each epoch
        self.shuffle: bool = shuffle
        # Training Indices
        self.indices = np.arange(self.meta_data.shape[0])
        # Number of points within the window
        self.window_size = window_size
        self.on_epoch_end()

    def __len__(self):
        # Denotes the number of batches per epoch
        return int(np.floor(self.indices.shape[0] / self.batch_size))

    def __getitem__(self, index):
        # Generate one batch of data
        batch_indices = self.indices[index * self.batch_size: (index + 1) * self.batch_size]
        meta_data_sub = [self.meta_data[k] for k in batch_indices]
        x, y = self.__data_generation(meta_data_sub)
        return x, y

    def on_epoch_end(self):
        # Update after each epoch
        self.indices = np.arange(self.meta_data.shape[0])
        if self.shuffle:
            np.random.shuffle(self.indices)

    def __data_generation(self, meta_data_sub):
        # Generate arrays containing a batch of input data
        x = np.empty((self.batch_size, self.window_size, config.PowerData.NUM_OF_COLS))
        y = np.empty(self.batch_size)

        #
        for idx, meta_row in enumerate(meta_data_sub):

            data_length = meta_row[config.Meta.END_ROW] - meta_row[config.Meta.START_ROW] + 1

            # Get random initial index of the window within the data instance
            if data_length - self.window_size > 0:
                rand_index = rand.randrange(data_length - self.window_size)
            else:
                rand_index = 0

            # Append the window data
            x[idx] = self.data[meta_row[config.Meta.START_ROW]: meta_row[config.Meta.END_ROW] + 1][rand_index: rand_index + self.window_size]

            # Append the label
            y[idx] = meta_row[config.Meta.DEVICE_TYPE]

        return x, y
