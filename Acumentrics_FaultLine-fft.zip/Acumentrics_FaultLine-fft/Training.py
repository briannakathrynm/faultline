import os

import numpy as np
import sklearn.preprocessing as preprop
import tensorflow as tf

import DataGenerator
import config
import data_prep_functions as dpf


class Training:

    def __init__(self,
                 data: np.memmap,
                 epochs: int,
                 meta: np.ndarray,
                 training_name: str,
                 batch_size: int = 32,
                 part_sizes: list = None,
                 visualize: bool = False,
                 verbose: bool = False,
                 window_length: float = 1):

        self.batch_size: int = batch_size
        self.data: np.memmap = data
        self.epochs: int = epochs
        self.meta: np.ndarray = meta
        self.model = None
        self.output_path: str = config.TRAINING_PATH + training_name + "/"
        self.part_sizes: list = part_sizes if part_sizes else [0.6, 0.3, 0.1]
        self.test_set = None
        self.train_set = None
        self.validation_set = None
        self.visualize: bool = visualize
        self.verbose: bool = verbose
        self.window_size: int = int(np.floor(window_length * config.INPUT_FREQ))

        # Check for valid partition sizes
        for item in self.part_sizes:
            assert item >= 0, f"Invalid Partition Size.\nGiven {self.part_sizes}"
        assert round(sum(self.part_sizes), 1) == 1, f"Invalid Partition Sizes.\nGiven {self.part_sizes}"

        # Check for valid window size
        assert self.window_size >= np.min(self.meta[:, 3] - self.meta[:, 2] + 1), \
            f"Window size must be less than the smallest data instance ({np.min(self.meta[:, 3] - self.meta[:, 2] + 1)})"

        # If the Training Directory does not exist, create one
        if not os.path.isdir(config.TRAINING_PATH):
            os.mkdir(config.TRAINING_PATH)

        # Create the Training Run subdirectory
        if not os.path.isdir(self.output_path):
            os.mkdir(self.output_path)

        print("Successfully created the Training Object")

    def load(self,
             model_path: str):

        # Load model from given file path
        self.model = tf.keras.models.load_model(model_path)

        print("Successfully loaded the model")

    def build(self):
        # Create model structure
        self.model = tf.keras.Sequential([
            tf.keras.layers.InputLayer(input_shape=(self.window_size, 4)),
            tf.keras.layers.LSTM(units=64, activation='relu'),
            tf.keras.layers.Reshape(target_shape=(64, 1)),
            tf.keras.layers.LSTM(units=128, activation='relu'),
            tf.keras.layers.Reshape(target_shape=(128, 1)),
            tf.keras.layers.LSTM(units=128, activation='relu'),
            tf.keras.layers.Flatten(),
            tf.keras.layers.Dense(units=64, activation='relu'),
            tf.keras.layers.Dense(units=64, activation='relu'),
            tf.keras.layers.Dense(units=np.unique(self.meta[:, 1]).size, activation='softmax')
        ])

        if self.verbose:
            # Summary of the model structure
            self.model.summary()

        # model.build() # Used for delayed build pattern?

        if self.visualize:
            # Visualize current model
            tf.keras.utils.plot_model(self.model, self.output_path + 'model_structure.png', show_shapes=True)

        # Compile the model
        self.model.compile(
            optimizer='adam',
            loss=tf.losses.sparse_categorical_crossentropy,
            metrics=['accuracy'])

        print("Successfully built the model")

    def prepare_data(self):
        # Normalization of input data
        self.data = preprop.normalize(self.data)

    def train(self):
        # Split the dataset into training, validation, and test datasets
        self.train_set, self.validation_set, self.test_set = dpf.split(
            meta=self.meta,
            output_path=self.output_path,
            partition_sizes=self.part_sizes
        )

        if self.verbose:
            # Print the class balances of the datasets
            dpf.check_balance(self.train_set, "Train")
            dpf.check_balance(self.validation_set, "Validation")
            dpf.check_balance(self.test_set, "Test")

        # Create generators for each dataset
        train_gen = DataGenerator.DataGenerator(
            data=self.data,
            meta=self.train_set,
            batch_size=self.batch_size,
            window_size=self.window_size,
            shuffle=True
        )

        validation_gen = DataGenerator.DataGenerator(
            data=self.data,
            meta=self.validation_set,
            batch_size=self.batch_size,
            window_size=self.window_size,
            shuffle=True
        )

        # Train the model on the train and validation sets
        self.model.fit_generator(
            generator=train_gen,
            steps_per_epoch=self.train_set.shape[0] // self.batch_size,
            epochs=self.epochs,
            verbose=1,
            callbacks=None,
            validation_data=validation_gen,
            validation_steps=self.validation_set.shape[0] // self.batch_size,
            validation_freq=1,
            class_weight=None,
            max_queue_size=10,
            workers=1,
            use_multiprocessing=False,
            shuffle=True,
            initial_epoch=0
        )

        print("Successfully trained the model")

    def evaluate(self):

        # Create generator for test dataset
        test_gen = DataGenerator.DataGenerator(
            data=self.data,
            meta=self.test_set,
            batch_size=self.batch_size,
            window_size=self.window_size,
            shuffle=True
        )

        # Evaluate the model with the test dataset
        self.model.evaluate_generator(
            generator=test_gen,
            steps=self.test_set.shape[0] // self.batch_size,
            callbacks=None,
            max_queue_size=10,
            workers=1,
            use_multiprocessing=False,
            verbose=1
        )

        print("Successfully evaluated the model")

    def save(self):

        # Save the model in output directory
        self.model.save(self.output_path + "model.h5")

        print("Successfully saved the model")

    def export(self):
        # Make the sub-directory for the saved model
        saved_model_path = self.output_path + "saved_model/"
        if not os.path.isdir(saved_model_path):
            os.mkdir(saved_model_path)

        # Save the model in the subdirectory
        tf.saved_model.save(self.model, saved_model_path)

        print("Successfully exported the model")
