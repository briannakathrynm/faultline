import numpy as np
import tensorflow as tf
import sklearn.preprocessing as preprop
from keras.models import Sequential
from keras.layers import Dense

import DataGenerator
import config
import data_prep_functions as dpf


class Training:

    def __init__(self,
                 data: np.ndarray,
                 epochs: int,
                 meta: np.ndarray,
                 training_name: str,
                 batch_size: int = 32,
                 part_sizes: list = None,
                 visualize: bool = False,
                 verbose: bool = False,
                 window_length: float = 1):
        self.batch_size: int = batch_size
        self.data: np.memmap = data
        self.epochs: int = epochs
        self.meta: np.ndarray = meta
        self.model = None
        self.output_path: str = config.TRAINING_PATH + training_name + "/"
        self.part_sizes: list = part_sizes if part_sizes else [0.6, 0.3, 0.1]
        self.test_set = None
        self.train_set = None
        self.validation_set = None
        self.visualize: bool = visualize
        self.verbose: bool = verbose
        self.window_size: int = int(np.floor(window_length * config.INPUT_FREQ))

        # Create model with no hidden layers, same number of outputs as inputs.
        # No bias needed.  No activation function, since FFT is linear.
        def build(self):
            # Create model structure
            self.model = tf.keras.Sequential([
                Dense(batch_size * 2, input_dim=batch_size * 2, use_bias=False)
            ])
            self.model.compile(loss='mean_squared_error', optimizer='adam')
            self.model.fit(X_in, epochs=100, batch_size=100)

        def prepare_data(self):
            # Normalization of input data
            self.data = preprop.normalize(self.data)

        def train(self):
            # Split the dataset into training, validation, and test datasets
            self.train_set, self.validation_set, self.test_set = dpf.split(
                meta=self.meta,
                output_path=self.output_path,
                partition_sizes=self.part_sizes
            )

            if self.verbose:
                # Print the class balances of the datasets
                dpf.check_balance(self.train_set, "Train")
                dpf.check_balance(self.validation_set, "Validation")
                dpf.check_balance(self.test_set, "Test")

            # Create generators for each dataset
            train_gen = DataGenerator.DataGenerator(
                data=self.data,
                meta=self.train_set,
                batch_size=self.batch_size,
                window_size=self.window_size,
                shuffle=True
            )

            validation_gen = DataGenerator.DataGenerator(
                data=self.data,
                meta=self.validation_set,
                batch_size=self.batch_size,
                window_size=self.window_size,
                shuffle=True
            )

            # Train the model on the train and validation sets
            self.model.fit_generator(
                generator=train_gen,
                steps_per_epoch=self.train_set.shape[0] // self.batch_size,
                epochs=self.epochs,
                verbose=1,
                callbacks=None,
                validation_data=validation_gen,
                validation_steps=self.validation_set.shape[0] // self.batch_size,
                validation_freq=1,
                class_weight=None,
                max_queue_size=10,
                workers=1,
                use_multiprocessing=False,
                shuffle=True,
                initial_epoch=0
            )

            print("Successfully trained the model")
