import argparse
import numpy as np
import pandas as pd

import Training
import config

if __name__ == "__main__":
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description='Train model on PLAID dataset')
    parser.add_argument('--epochs', action='store', dest='epochs', required=True, type=int,
                        help='Set the number of training epochs')
    parser.add_argument('--name', '-n', action='store', dest='run_name', required=True,
                        help='Name of the output directory')
    parser.add_argument('--batch', action='store', dest='batch_size', default=32, type=int,
                        help='Set the batch size for the training (Default: 32')
    parser.add_argument('--export', action='store_true', dest='export',
                        help='Set flag to export the model (Default: False')
    parser.add_argument('--input', '-i', action='store', dest='input_path',
                        help='Name of the input directory')
    parser.add_argument('--load', action='store', dest='model_path', default='',
                        help='Set the starting point of the model via a model file path')
    parser.add_argument('--partitions', action='store', nargs=3, dest='partition_sizes', default=[0.6, 0.3, 0.1],
                        type=float,
                        help='Set the size of the training, validation, and test partitions (Default: 0.6, 0.3, 0.1')
    parser.add_argument('-v', '--verbose', action='store_true', dest='isVerbose',
                        help='Print additional information to the standard output')
    parser.add_argument('--visualize', action='store_true', dest='isVisualized',
                        help='Produce visualization of the model structure')
    parser.add_argument('--window', action='store', dest='window_length', default=1, type=float,
                        help='Set the length of the data window in seconds (Default: 1')
    args = parser.parse_args()

    # Read meta CSV data
    meta = pd.read_csv(config.POWER_PATH + "meta.csv").to_numpy()

    # Read data from binary file
    data = np.memmap(
        filename=config.POWER_PATH + "total_power.bin",
        dtype=np.float64,
        mode="r",
        shape=(meta[meta.shape[0] - 1][config.Meta.END_ROW] + 1, config.PowerData.NUM_OF_COLS)
    )

    # Create an instance of the training object
    training = Training.Training(
        data=data,
        epochs=args.epochs,
        meta=meta,
        training_name=args.run_name,
        batch_size=args.batch_size,
        part_sizes=args.partition_sizes,
        visualize=args.isVisualized,
        verbose=args.isVerbose,
        window_length=args.window_length
    )

    # Run through the dataset training
    training.prepare_data()

    # If the user gave an input model, load the model. If not, build one
    if args.model_path:
        training.load(args.model_path)
    else:
        training.build()
    training.train()
    training.evaluate()
    training.save()
    if args.export:
        training.export()

