from enum import IntEnum

PLAID_PATH = "./Plaid/"
POWER_PATH = "./Power_Data/"
IMAGES_PATH = "./Images/"
TRAINING_PATH = "./Training/"
SAMPLING_FREQ = 30000
INPUT_FREQ = 60


class Meta(IntEnum):
    ID = 0
    DEVICE_TYPE = 1
    START_ROW = 2
    END_ROW = 3
    NUM_OF_COLS = 4


class PowerData(IntEnum):
    APPARENT_POWER = 0
    REAL_POWER = 1
    REACTIVE_POWER = 2
    POWER_FACTOR = 3
    NUM_OF_COLS = 4
