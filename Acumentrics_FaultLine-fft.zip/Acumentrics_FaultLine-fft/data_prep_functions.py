import pandas as pd
import sklearn.model_selection as sk_mod
import numpy as np
import config


# Splits input CSV into training, validation, and test CSVs based on the given percentages
def split(meta,
          output_path,
          partition_sizes=[0.6, 0.3, 0.1]):

    # Get partition sizes
    train_size = partition_sizes[0]
    validation_size = partition_sizes[1]
    test_size = partition_sizes[2]

    # Create train partition
    train, temp = sk_mod.train_test_split(meta,
                                          train_size=train_size,
                                          test_size=validation_size + test_size,
                                          stratify=meta[:, 1],  # Used to ensure class balance
                                          shuffle=True)

    # Split remaining partition into validation and test partitions
    validation, test = sk_mod.train_test_split(temp,
                                               train_size=validation_size / (validation_size + test_size),
                                               test_size=test_size / (validation_size + test_size),
                                               stratify=temp[:, 1],  # Used to ensure class balance
                                               shuffle=True)

    # Saves partition output to a CSV
    pd.DataFrame(data=train,
                 index=np.arange(train.shape[0]),
                 columns=["ID", "Device Type", "Start Row","End Row"]).to_csv(output_path + "train.csv",
                                                                              index=False)
    pd.DataFrame(data=validation,
                 index=np.arange(validation.shape[0]),
                 columns=["ID", "Device Type", "Start Row","End Row"]).to_csv(output_path + "validation.csv",
                                                                              index=False)

    pd.DataFrame(data=test,
                 index=np.arange(test.shape[0]),
                 columns=["ID", "Device Type", "Start Row","End Row"]).to_csv(output_path + "test.csv",
                                                                              index=False)

    return train, validation, test


# Checks the percentage of each label within a CSV
def check_balance(meta, name):

    # Gets the unique counts for each device type
    unique_vals, unique_counts = np.unique(meta[:, 1], return_counts=True)

    # Converts device type counts into percentages
    percentages = unique_counts / meta.shape[0]

    # Prints percentages
    print("Class Percentages of " + name + ":")
    for i in range(len(unique_counts)):
        print(unique_vals[i], ":", percentages[i])
    print()
