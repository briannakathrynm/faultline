# Take voltage/current data as input, gives FFT as the result
import numpy as np
from scipy.fftpack import fft
import matplotlib.pyplot as plt

# Will be placed into the "preparse.py" function to access the raw voltage and current data

def FFT_Function(input_CSV_path):
    """ Function that takes raw data and creates/plots the FFT of the data
        :param input_CSV_path: input_df from preparse, the raw voltages and currents of the CSV files
        :return:
        """
    # X value for model is the concatenated array of voltages and currents, Y is the label for the Model

    # Sample creation
    N = 32
    batch = 10000

    # Convert raw data into FFT arrays, np.abs combines real and imaginary parts
    input_df = pd.read_csv(input_CSV_path, names=["Current", "Voltage"])
    X_in = np.concatenate([np.abs(fft(input_df["Voltage"])[0: N//2])], np.abs(fft(input_df["Current"]))[0:N//2])

    # Attempt at plotting the FFTs
    T = 1.0 / 800.0     # Spacing for graph
    xf = np.linspace(0.0, 1.0 / (2.0 * T), N // 2)
    plt.plot(xf, 2.0 / N * X_in)
    plt.grid()
    plt.show()
