import numpy as np
from scipy import fftpack


def fft_function(
        current,
        voltage,
):
    """
    This function:
        * takes raw Current and Voltage time-series data,
        * applies an FFT to Current and Voltage time-series,
        * thresholds the amplitude,
        * and produces a binary vector for input to a Neural Net.

    :param current: Time-series of current.
    :param voltage: Time-series of voltage.
    """
    # Convert to FFT data
    fft_c = np.abs(fftpack.fft(current))
    fft_c = fft_c[0:fft_c.shape[0] // 2]

    fft_v = np.abs(fftpack.fft(voltage))
    fft_v = fft_v[0:fft_v.shape[0] // 2]

    threshold_c = np.max(fft_c) / 10
    threshold_v = np.max(fft_v) / 10
    # Assigning binary values according to threshold for Current
    bin_vector_c = fft_c > threshold_c
    bin_vector_v = fft_v > threshold_v

    # Concatenation of the two binary vectors
    bin_vector = np.concatenate((bin_vector_c, bin_vector_v))

    return bin_vector
