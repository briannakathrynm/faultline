import json
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import config
import argparse
import tensorflow as tf

sns.set_style("dark")


# Based on the given DataFrame, generates a plot of the "x" column and "y" column in the given color that will be saved
# as the given image_path.
def gen_save_figure(x_name,
                    y_name,
                    df,
                    image_path,
                    color_name="black",
                    plot_type="scatter"):
    if plot_type == "line":
        plot = sns.lineplot(x=x_name, y=y_name, data=df, linewidth=1, color=color_name)
    elif plot_type == "scatter":
        plot = sns.scatterplot(x=x_name, y=y_name, data=df, s=3, marker=".", linewidth=0, color=color_name)
    fig = plot.get_figure()
    fig.savefig(image_path, dpi=700)
    plt.close()


def main():
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description='Preprocess PLAID into power data')
    parser.add_argument('--visualize', action='store_true', dest="isVisualized",
                        help='Produces visualizations for PLAID data')
    parser.add_argument('-d', nargs='+', dest='devices',
                        help='List of device types to be processed. If no type is provided, all device types are processed')
    args = parser.parse_args()

    # Generate a directory for the power data output
    if not os.path.isdir(config.POWER_PATH):
        os.mkdir(config.POWER_PATH)

    # Generate a directory for the image output
    if not os.path.isdir(config.IMAGES_PATH) and args.isVisualized:
        os.mkdir(config.IMAGES_PATH)

    # DataFrame containing the power data for all instances
    total_power_df = pd.DataFrame(columns=["Apparent Power",
                                           "Real Power",
                                           "Reactive Power",
                                           "Power Factor"])

    # DataFrame containing the meta data for the power data
    total_power_meta_df = pd.DataFrame(columns=["ID",
                                                "Device Type",
                                                "Start Row",
                                                "End Row"])

    # Label dictionary for one-hot vector enumeration
    labels = {}

    # Generates a directory of images and CSV files for PLAID
    for file in os.listdir(config.PLAID_PATH):
        if file.endswith(".json"):
            # Load each json file
            with open(config.PLAID_PATH + file, 'r') as json_file:
                meta = json.load(json_file)

            # Repeat for selected devices in the json file
            for dset in meta:
                if not args.devices or dset["meta"]["type"] in args.devices:

                    # Read the data instance CSV
                    input_CSV_path = config.PLAID_PATH + "CSV/" + dset["id"] + ".csv"
                    input_df = pd.read_csv(input_CSV_path, names=["Current", "Voltage"])

                    # Add additional columns to the DataFrame
                    time = [val * (1 / config.SAMPLING_FREQ) for val in range(0, input_df.shape[0])]

                    input_df["Time"] = pd.Series(time)
                    input_df["Power"] = input_df["Current"] * input_df["Voltage"]

                    # Calculate the number of cycles of the voltage/current waves
                    points_per_cycle = config.SAMPLING_FREQ // config.INPUT_FREQ
                    number_of_periods = int(input_df.shape[0] // points_per_cycle)

                    # Create the initial power DataFrame
                    power_df = pd.DataFrame(columns=["Apparent Power",
                                                     "Real Power",
                                                     "Reactive Power",
                                                     "Power Factor"])

                    # Calculate power parameters for each cycle
                    for i in range(0, number_of_periods):
                        # Get one period of data from the larger dataset
                        voltage_set = input_df["Voltage"].to_numpy()[
                                      i * points_per_cycle: i * points_per_cycle + points_per_cycle]
                        current_set = input_df["Current"].to_numpy()[
                                      i * points_per_cycle: i * points_per_cycle + points_per_cycle]

                        # Calculate the RMS value and index for both current and voltage
                        V_rms = np.amax(voltage_set) / np.sqrt(2)
                        I_rms = np.amax(current_set) / np.sqrt(2)

                        v_max_index = np.argmax(voltage_set)
                        curr_max_index = np.argmax(current_set)

                        # Calculate the phase shift between current and voltage
                        time_delay = abs(curr_max_index - v_max_index) / config.SAMPLING_FREQ
                        phase_shift = 2 * np.pi * config.INPUT_FREQ * time_delay

                        # Calculate the complex power components
                        app_power = V_rms * I_rms
                        real_power = app_power * np.cos(phase_shift)
                        react_power = app_power * np.sin(phase_shift)
                        power_factor = np.cos(phase_shift)

                        # Append the power value to the power dataset
                        power_df = power_df.append({'Apparent Power': app_power,
                                                    'Real Power': real_power,
                                                    'Reactive Power': react_power,
                                                    'Power Factor': power_factor}, ignore_index=True)

                    # If an appliance does not already have a label, add label to dictionary
                    if not dset["meta"]["type"] in labels:
                        labels[dset["meta"]["type"]] = len(labels)

                    # Append power meta data
                    total_power_meta_df = total_power_meta_df.append({"ID": dset["id"],
                                                                      "Device Type": labels[dset["meta"]["type"]],
                                                                      "Start Row": total_power_df.shape[0],
                                                                      "End Row": total_power_df.shape[0] +
                                                                                 power_df.shape[0] - 1},
                                                                     ignore_index=True)

                    # Append data instance to full power DataFrame
                    total_power_df = total_power_df.append(power_df, ignore_index=True)

                    # Generate Images
                    if args.isVisualized:
                        # If appliance directory does not exist, create one
                        image_app_path = config.IMAGES_PATH + dset["meta"]["type"] + "/"
                        if not os.path.isdir(image_app_path):
                            os.mkdir(image_app_path)
                            empty_df = pd.DataFrame(columns=['Id',
                                                             'Collection Time',
                                                             'Sampling Frequency',
                                                             'Location',
                                                             'Length',
                                                             'Voltage Plot',
                                                             'Current Plot',
                                                             'Instantaneous Power Plot',
                                                             'Apparent Power',
                                                             'Real Power',
                                                             'Reactive Power',
                                                             'Power Factor'])
                            empty_df.to_csv(image_app_path + dset["meta"]["type"] + ".csv", index=False)

                        # Create instance subdirectory
                        id_path = image_app_path + dset["id"] + "/"
                        if not os.path.isdir(id_path):
                            os.mkdir(id_path)

                        # Generate and save plots
                        gen_save_figure(x_name="Time",
                                        y_name="Current",
                                        df=input_df,
                                        image_path=id_path + "Current.png",
                                        color_name="blue")
                        gen_save_figure(x_name="Time",
                                        y_name="Voltage",
                                        df=input_df,
                                        image_path=id_path + "Voltage.png",
                                        color_name="red")
                        gen_save_figure(x_name="Time",
                                        y_name="Power",
                                        df=input_df,
                                        image_path=id_path + "Instant_Power.png")
                        gen_save_figure(x_name="Index",
                                        y_name="Apparent Power",
                                        df=power_df,
                                        image_path=id_path + "Apparent_Power.png",
                                        plot_type="line")
                        gen_save_figure(x_name="Index",
                                        y_name="Real Power",
                                        df=power_df,
                                        image_path=id_path + "Real_Power.png",
                                        plot_type="line")
                        gen_save_figure(x_name="Index",
                                        y_name="Reactive Power",
                                        df=power_df,
                                        image_path=id_path + "Reactive_Power.png",
                                        plot_type="line")
                        gen_save_figure(x_name="Index",
                                        y_name="Power Factor",
                                        df=power_df,
                                        image_path=id_path + "Power_Factor.png",
                                        plot_type="line")

                        # Append to the appliance CSV file
                        app_df = pd.read_csv(image_app_path + dset["meta"]["type"] + ".csv")
                        app_df = app_df.append({'Id': dset["id"],
                                                'Collection Time': dset["meta"]["header"]["collection_time"],
                                                'Sampling Frequency': dset["meta"]["header"]["sampling_frequency"],
                                                'Location': dset["meta"]["location"],
                                                'Length': dset["meta"]["instances"]["length"],
                                                'Voltage Plot': os.getcwd() + id_path[1:] + "Voltage.png",
                                                'Current Plot': os.getcwd() + id_path[1:] + "Current.png",
                                                'Instantaneous Power Plot': os.getcwd() + id_path[
                                                                                          1:] + "Instant_Power.png",
                                                'Apparent Power': os.getcwd() + id_path[1:] + "Apparent_Power.png",
                                                'Real Power': os.getcwd() + id_path[1:] + "Real_Power.png",
                                                'Reactive Power': os.getcwd() + id_path[1:] + "Reactive_Power.png",
                                                'Power Factor': os.getcwd() + id_path[1:] + "Power_Factor.png"},
                                               ignore_index=True)
                        app_df.to_csv(image_app_path + dset["meta"]["type"] + ".csv", index=False)

                    print("Finished with " + dset["id"])

    # Convert device type to a DataFrame containing the one-hot vectors
    temp = np.zeros((total_power_meta_df["Device Type"].size, len(labels)))
    for idx, val in enumerate(total_power_meta_df["Device Type"].to_numpy()):
        temp[idx][val] = 1
    one_hot_df = pd.DataFrame(data=temp)

    # Write one-hot vectors to CSV
    one_hot_df.to_csv(config.POWER_PATH + "labels.csv", index=False)

    # Write the power meta data to CSV
    total_power_meta_df.to_csv(config.POWER_PATH + "meta.csv", index=False)

    # Create a binary file for storage of power data
    fp = np.memmap(filename=config.POWER_PATH + "total_power.bin",
                   dtype=np.float64,
                   mode="w+",
                   shape=total_power_df.shape)

    # Copy power data into binary memory
    fp[:] = total_power_df.to_numpy()[:]

    # Flush data to memory
    del fp


if __name__ == "__main__":
    main()
