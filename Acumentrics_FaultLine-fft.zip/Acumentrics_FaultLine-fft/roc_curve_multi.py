import os
from typing import Tuple

import matplotlib.pyplot as plt
import numpy as np
from sklearn import metrics


def rescale_predictions(predictions: np.ndarray, labels: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """ Rescale prediction probabilities for drawing roc curves.

    :param predictions: Batch of prediction probabilities from NN.
    :param labels: Correct class labels.
    :return: Whether the prediction was correct, and the rescaled probabilities.
    """
    truth = np.max(predictions, axis=1)

    probs = [0] * len(labels)
    for i, (row, label) in enumerate(zip(predictions, labels)):
        probs[i] = row[label]
        truth[i] = (label == np.argmax(row))
        row[label] = 0.

    others: np.ndarray = np.max(predictions, axis=1)

    for i in range(len(probs)):
        probs[i], others[i] = probs[i] / (probs[i] + others[i]), others[i] / (probs[i] + others[i])
        if not truth[i]:
            probs[i] = 1. - probs[i]

    return np.asarray(truth, dtype=np.int), np.asarray(probs)


def plot_roc_multi(labels, truths, predictions, directory):
    """ Plots multi-class roc curves on a shape.

    :param labels: Correct class labels.
    :param truths: Whether the prediction was correct.
    :param predictions: Re-Scaled prediction probabilities.
    :param directory: Directory where the plot will be saved.
    :return:
    """
    plt.clf()
    fig = plt.figure()

    classes = np.unique(labels)
    for c in classes:
        y_true = truths[np.where(labels == c)]
        y_score = predictions[np.where(labels == c)]
        fpr, tpr, _ = metrics.roc_curve(y_true, y_score)
        auc = metrics.auc(fpr, tpr)
        plt.plot(fpr, tpr, label=f'class {c}, area = {auc:.4f}')

    plt.xlim([0.0, 1.05])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    # plt.title(f'')
    plt.legend(loc="lower right")
    plt.show()

    plt.close('all')

    # os.makedirs(directory, exist_ok=True)
    # filepath = os.path.join(directory, f'roc_curves.png')
    # fig.savefig(filepath)

    return


if __name__ == '__main__':
    plot_roc_multi()
