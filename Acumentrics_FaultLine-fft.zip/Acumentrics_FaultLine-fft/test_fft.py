import matplotlib.pyplot as plt
import numpy as np

from new_fft import fft_function


def test():
    frequency = 600
    amplitude = 3
    noise = 1

    time = np.arange(start=0, stop=10, step=1/frequency) * 2 * np.pi
    current = amplitude * np.sin(time) + noise * np.random.randn(time.shape[0])
    voltage = amplitude * np.sin(time) + noise * np.random.randn(time.shape[0])

    bin_vector = fft_function(current, voltage)
    time = np.arange(start=0, stop=bin_vector.shape[0], step=1)

    plt.clf()
    fig = plt.figure()
    plt.scatter(time, bin_vector, label='current vs time')
    plt.xlabel('freq')
    plt.ylabel('amplitude')
    plt.legend(loc="lower right")
    plt.show()

    return


if __name__ == '__main__':
    test()
