import numpy as np

from roc_curve_multi import rescale_predictions, plot_roc_multi


def test():
    num_classes = 5
    batch_size = 1024

    # Randomly create array of size num_classes by batch_size
    predictions = np.random.random(size=(batch_size, num_classes))
    sums = np.linalg.norm(predictions, ord=1, axis=1, keepdims=True)
    predictions = predictions / sums
    # Randomly creates a number of classes and assigns them
    labels = np.random.randint(low=0, high=num_classes, size=batch_size)

    truths, predictions = rescale_predictions(predictions, labels)
    plot_roc_multi(labels, truths, predictions, '')

    return


if __name__ == '__main__':
    np.random.seed(42)
    test()
